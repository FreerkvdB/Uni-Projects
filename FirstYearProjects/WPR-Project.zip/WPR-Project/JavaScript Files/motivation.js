function giveMotivation(){ //Function dispalys a random motivation message when button is clicked
    let motivation = ["You can do it!", "You are amazing!", "You are a star!", 
        "You are a champion!", "You are a winner!", "You are a hero!", 
        "You are a legend!", "You are a boss!", "You are a beast!"]
    
    let randomIndex = Math.floor(Math.random() * motivation.length); //Math.random() selects a random number between 0 and 1, we multiply it by the length of the array to get a random index
    let randomMotivation = motivation[randomIndex];
     document.querySelector(".tip").style.display = 'flex';
     document.querySelector(".tip-text").innerHTML = randomMotivation;
    setTimeout(function(){
        
     document.querySelector(".tip").style.display = 'none';

    },5000);
}


