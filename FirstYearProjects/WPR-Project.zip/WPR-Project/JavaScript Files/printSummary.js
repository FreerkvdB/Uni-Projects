
//We create a function that will display a print dialog of the workout log

function printSummary(){
    window.print(); //opens the print dialog
}

console.log("Freerk")