const inputBox1 = document.getElementById("type");
const inputBox2 = document.getElementById("duration");
const inputBox3 = document.getElementById("calories");
const listContainer = document.getElementById("list-container");
const date = document.getElementById("date");

let workoutData = JSON.parse(localStorage.getItem("array") || "[]");
let favourite = JSON.parse(localStorage.getItem("fav") || "[]");

let button = document.getElementById("addButton");
button.addEventListener("click", addTask);

function addTask() {
    if (inputBox1.value === '' || inputBox2.value === '' || inputBox3.value === '' || date.value === '') {
        alert("You must enter all activity details.");
    } else {
        const workout = {
            type: inputBox1.value,
            duration: Number(inputBox2.value),
            calories: Number(inputBox3.value),
            date: date.value
        };

        workoutData.push(workout);
        displayWorkout(workout);

        saveData();
        ClearData();
    }
}

function displayWorkout(workout) {
    let li = document.createElement("li");
    li.classList.add("workout-item");
    li.innerHTML = `
        ${workout.type} &emsp; ${workout.duration} min &emsp; ${workout.calories} kcal &emsp; ${workout.date}
        <button class="del-btn">❌</button>
        <button class="fav-btn">
            <img src="../Images/notFavourited.png.jpg" alt="favourite-icon" class="favourite" data-type="${workout.type}" data-date="${workout.date}">
        </button>
        
    `;
    listContainer.appendChild(li);

    // Add event listeners for the favorite and delete buttons
    const favButton = li.querySelector('.fav-btn img');
    favButton.addEventListener("click", () => toggleFavorite(favButton, workout));
    li.querySelector('.del-btn').addEventListener("click", () => deleteWorkout(workout, li));

    // Check if workout is already in favorites and update the image accordingly
    if (isFavorite(workout)) {
        favButton.src = "../Images/Favourite.jpg"; // Mark as favorite
    }
}

function toggleFavorite(favButton, workout) {
    const isCurrentlyFav = favButton.src.includes("Favourite.jpg"); // Compare against 'Favourite.jpg'
    
    if (isCurrentlyFav) {
        favButton.src = "../Images/notFavourited.png.jpg"; // Not favorite anymore
        // Remove from favorites
        favourite = favourite.filter(fav => !(fav.date === workout.date && fav.type === workout.type));
    } else {
        favButton.src = "../Images/Favourite.jpg"; // Mark as favorite
        // Add to favorites
        favourite.push(workout);
    }

    saveData();
}

function isFavorite(workout) {
    return favourite.some(fav => fav.date === workout.date && fav.type === workout.type);
}

function deleteWorkout(workout, li) {
    const index = workoutData.findIndex(w => w.date === workout.date && w.type === workout.type);
    if (index > -1) {
        workoutData.splice(index, 1); // Remove workout from the main list
        li.remove(); // Remove workout from the DOM
        saveData();
    }
}

function saveData() {
    localStorage.setItem("array", JSON.stringify(workoutData));
    localStorage.setItem("fav", JSON.stringify(favourite));
}

function showWorkouts() {
    listContainer.innerHTML = '';
    workoutData.forEach(workout => {
        displayWorkout(workout);
    });
}

function ClearData() {
    inputBox1.value = "";
    inputBox2.value = "";
    inputBox3.value = "";
    date.value = '';
}

showWorkouts(); // Display the saved workouts on page load
