let Favourite ={
    WorkoutType: "",
    WorkoutDuration: "",
    CaloriesBurned: "",
    WorkoutDate: "",
}

function saveFavourite(){
    let favourite = JSON.stringify(Favourite);  //JSON.stringify converts a JavaScript object to a JSON string to be stored in localStorage
    localStorage.setItem("Favourite", favourite); //localStorage allows you to store key/value pairs in a web browser with no expiration date.
    alert("Favourite saved!");
}

function loadFavourite(){
    let favourite = localStorage.getItem("Favourite");
    Favourite = JSON.parse(favourite);
    alert("Favourite loaded!");
}

function displayFavourite(){
    document.getElementById("type").innerHTML = Favourite.WorkoutType;
    document.getElementById("duration").innerHTML = Favourite.WorkoutDuration;
    document.getElementById("calories").innerHTML = Favourite.CaloriesBurned;
    document.getElementById("date").innerHTML = Favourite.WorkoutDate;
}

if(Button.id == "save" && Button.id == "click"){
    Favourite.WorkoutType = document.getElementById("type").value;
    Favourite.WorkoutDuration = document.getElementById("duration").value;
    Favourite.CaloriesBurned = document.getElementById("calories").value;
    Favourite.WorkoutDate = document.getElementById("date").value;
    saveFavourite();
}

if(localStorage.getItem("Favourite") != null){
    loadFavourite();
    displayFavourite();
}

console.log("Freerk")