import { getWorkoutData } from './actLogger.js';
document.addEventListener("DOMContentLoaded", function () {
    const workoutData = getWorkoutData();

    // Calculate statistics
    const totalWorkouts = workoutData.length;
    const totalCalories = workoutData.reduce((sum, workout) => sum + workout.calories, 0);
    const averageDuration = totalWorkouts ? (workoutData.reduce((sum, workout) => sum + workout.duration, 0) / totalWorkouts).toFixed(2) : 0;

    // Update the DOM with statistics (only if elements exist)
    document.getElementById('totalWorkouts')?.innerText = totalWorkouts;
    document.getElementById('totalCalories')?.innerText = totalCalories;
    document.getElementById('averageDuration')?.innerText = averageDuration;

    // Prepare data for the chart
    const labels = workoutData.map(workout => workout.date);
    const durations = workoutData.map(workout => workout.duration);
    const calories = workoutData.map(workout => workout.calories);

    // Create the chart
    const ctx = document.getElementById('workoutChart')?.getContext('2d');
    if (ctx) {
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Duration (minutes)',
                        data: durations,
                        backgroundColor: 'gray',
                        borderColor: 'gray',
                        borderWidth: 1
                    },
                    {
                        label: 'Calories Burned',
                        data: calories,
                        backgroundColor: 'crimson',
                        borderColor: 'crimson',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
});

console.log("gabi");