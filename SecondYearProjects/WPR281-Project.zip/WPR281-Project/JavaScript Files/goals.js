const inputBox = document.getElementById("input-box");
const listContainer = document.getElementById("list-container");
const progress = document.querySelector('.progress-bar');
let item_counter = 0;
let progress_count = 0;
let click_counter = 0;

function addTask() {
    if (inputBox.value === '') {
        alert("You must enter an activity");
    } else {
        let li = document.createElement("li");
        li.innerHTML = inputBox.value;
        listContainer.appendChild(li);
        let span = document.createElement("span");
        span.innerHTML = "&#10006"; // cross icon 
        li.appendChild(span);
        item_counter++;
        console.log(item_counter);
    }
    inputBox.value = "";
    saveData();
    ProgressUpdate();
}

listContainer.addEventListener("click", function (e) {
    if (e.target.tagName === "LI") {
        e.target.classList.toggle("checked");
        if (e.target.classList.contains("checked")) {
            progress_count++;
        } else {
            progress_count--;
        }
        ProgressUpdate();
        saveData();
    } else if (e.target.tagName === "SPAN") {
        if (e.target.parentElement.classList.contains("checked")) {
            progress_count--;
        }
        e.target.parentElement.remove();
        item_counter--;
        ProgressUpdate();
        saveData();
    }
}, false);

function ProgressUpdate() {
    if (item_counter === 0) {
        progress.style.width = `0%`; 
        progress.innerText = `0%`; 
    } else {
        let progressPercentage = Math.ceil((progress_count / item_counter) * 100);
        progress.style.width = `${progressPercentage}%`;
        progress.innerText = `${progressPercentage}%`;
        console.log(`progress % ${progressPercentage}%`);
    }
}

function saveData() {
    localStorage.setItem("dataSaved", listContainer.innerHTML);
}

function showtask() {
    listContainer.innerHTML = localStorage.getItem("dataSaved");
    let items = listContainer.getElementsByTagName("li");
    item_counter = items.length;
    progress_count = 0;
    for (let item of items) {
        if (item.classList.contains("checked")) {
            progress_count++;
        }
    }
    ProgressUpdate();
}
console.log("marcus")
showtask();