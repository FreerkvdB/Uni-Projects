const inputBox1 = document.getElementById("type");
const inputBox2 = document.getElementById("duration");
const inputBox3 = document.getElementById("calories");
const listContainer = document.getElementById("list-container");
const date = document.getElementById("date");


let workoutData = JSON.parse(localStorage.getItem("array") || "[]");

function addTask() {
    if (inputBox1.value === '' || inputBox2.value === '' || inputBox3.value === '' || date.value === '') {
        alert("You must enter an activity");
    } else {
        let li = document.createElement("li");
        li.innerHTML = `${inputBox1.value} &emsp;&emsp;&emsp;&emsp; ${inputBox2.value} 
                        &emsp;&emsp;&emsp;&emsp;&emsp; ${inputBox3.value} 
                        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; ${date.value}`;
        listContainer.appendChild(li);
        let span = document.createElement("span");
        span.innerHTML = "&#10006"; // cross icon
        li.appendChild(span);
    }

    // Convert duration and calories to numbers before storing
    workoutData.push({ 
        date: date.value, 
        duration: Number(inputBox2.value), 
        calories: Number(inputBox3.value) 
    });
   

    saveData();
    ClearData();
}
console.log(workoutData);

listContainer.addEventListener("click", function (e) {
    if (e.target.tagName === "LI") {
        e.target.classList.toggle("checked");
        saveData();
    } else if (e.target.tagName === "SPAN") {
        e.target.parentElement.remove();
        //remove from the array 
        saveData();
    }
}, false);

function saveData() {
    localStorage.setItem("data", listContainer.innerHTML);
    localStorage.setItem("array", JSON.stringify(workoutData)); 
    
}

function showtask() {
    listContainer.innerHTML = localStorage.getItem("data") || "";
    workoutData = JSON.parse(localStorage.getItem("array") || "[]"); 
}

function ClearData() {
    inputBox1.value = "";
    inputBox2.value = "";
    inputBox3.value = "";
    date.value = '';
}

// find a way to export workoutData


showtask();
console.log("gabi+marcus");

