# 🏪 Stock Inventory System for Small Shops

## 📖 Project Overview
This project is a **Stock Inventory System** built in **C#** for small shops.  
It replaces manual tracking methods (pen & paper or spreadsheets) with a **user‑friendly, automated system** that reduces errors, provides low‑stock alerts, and scales as the business grows.

The system uses **OOP** concepts and implements:
- **Classes & Objects** for product modeling
- **Custom Events & Delegates** to trigger low‑stock alerts
- **Multithreading** to run background checks
- **Interfaces** for modular design
- **Polymorphism** for extensibility
- **Exception Handling** for safe input

---

## 👥 Contributors
- Freerk Van Den Bos (602074)  
- Michiel Coenraad TerBlance (601744)  
- Jordan Lee Naidoo (602463)  

---

## 📂 Features
- Add, remove, and update products
- Automatic low‑stock alerts via events
- Background stock checker thread
- Product list display
- Scalable and extensible architecture

---

## 🧰 Requirements
- **.NET SDK** and **Visual Studio** (or Rider) to run the app
- **GitHub account**
- **GitHub Desktop** (recommended for local development) — https://desktop.github.com/

> GitHub Desktop installs Git for you. You don’t need the command line for the workflow below.

---

## 🚀 Getting the Code (No Command Line)

### Option A — Clone with **GitHub Desktop**
1. Open the project repository page on GitHub.
2. Click **Code** → **Open with GitHub Desktop** (or in GitHub Desktop: **File** → **Clone repository…** → **URL** and paste your repo URL).
3. Choose a local path and click **Clone**.
4. In GitHub Desktop, click **Open in Visual Studio** to open the solution.

### Option B — Work directly on the **GitHub website** (for small edits)
1. Open the repository on GitHub.
2. Use the **branch dropdown** (top‑left near the file list) to create a **new branch** (see naming rules below).
3. Browse to a file → click the **pencil icon** to edit → make changes.
4. At the bottom, write a clear commit message and click **Commit changes** (to your branch).
5. Click **Compare & pull request** to open a PR into `main` (see review flow below).

---

## 🌿 Branching Strategy (Don’t break `main`)
We use a **branch‑per‑feature** workflow. No direct commits to `main`.

**Branch naming:**
- Features: `feature/<short-desc>` e.g., `feature/low-stock-alert`
- Bug fixes: `bugfix/<short-desc>`
- Docs: `docs/<short-desc>`

> Tip: Keep branches small and focused. One PR per feature/fix.

---

## 💻 Working in **GitHub Desktop** (Step‑by‑Step)
1. **Sync first**
   - In GitHub Desktop select the repo → ensure **Current Branch: `main`** → click **Fetch origin** (or **Pull** if available).
2. **Create a branch**
   - Click **Current Branch** → **New Branch** → name it using the rules above → **Create branch** → **Publish branch**.
3. **Develop locally**
   - Click **Open in Visual Studio**, make changes, test locally.
4. **Commit your work**
   - Back in GitHub Desktop → review changed files → write a clear **Summary** and optional **Description** → **Commit to `<your-branch>`**.
5. **Push your branch**
   - Click **Push origin** to upload your commits.
6. **Open a Pull Request**
   - In GitHub Desktop: **Branch** → **Create Pull Request** (opens the GitHub page).
   - On GitHub, fill in the PR template (what/why/how to test) → assign **reviewers** → **Create pull request**.
7. **Address feedback & merge**
   - Make any requested changes on the same branch → **Commit** → **Push** → PR updates automatically.
   - When approved and checks pass, **Merge** the PR into `main` on GitHub.
8. **Update your local `main`**
   - Switch back to `main` in GitHub Desktop → **Fetch/Pull** to stay up to date before starting the next branch.

---

## 🌐 Working on the **GitHub website** (Step‑by‑Step)
1. Go to the repository → open the **branch dropdown** → type a new branch name → **Create branch**.
2. Navigate to a file → click the **pencil** to edit (or **Add file** → **Create new file** / **Upload files**).
3. Write a meaningful **commit message** → click **Commit changes** to your branch.
4. Click **Compare & pull request** → add description, screenshots if needed → assign reviewers → **Create pull request**.
5. Wait for review, then **Merge** when approved. Don’t forget to **delete the branch** after merge to keep things tidy.

---

## 🧪 Pull Request Review Checklist
- ✅ Descriptive title and summary (what changed, why, how to test)
- ✅ Builds and runs locally
- ✅ No unrelated changes or large diffs
- ✅ Names and comments are clear
- ✅ At least **1 reviewer approval**
- ✅ All checks pass (CI if configured)

---

## 🛡️ (Recommended) Protect the `main` branch
On GitHub (repo **Settings** → **Branches** → **Add branch protection rule**):
- Require **pull request** before merging
- Require **approvals** (e.g., at least 1)
- Dismiss stale approvals when new commits are pushed
- (Optional) Require status checks to pass

This prevents direct pushes and accidental breaks.

---

## ▶️ Running the Application
1. Open the solution in **Visual Studio** (from GitHub Desktop or manually).
2. **Build** the solution (Ctrl+Shift+B).
3. **Run/Debug** (F5) and test the features you changed.

---

## 📜 License
This project is for **educational purposes** and not licensed for commercial use.
